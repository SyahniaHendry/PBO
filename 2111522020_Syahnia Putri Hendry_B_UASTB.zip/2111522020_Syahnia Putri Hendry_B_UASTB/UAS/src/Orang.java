//class Orang
public class Orang 
{
    String nama;

    //constructor
    public Orang()
    {

    }

    //constructor
    public Orang (String nama)
    {
        this.nama = nama;
        System.out.println("Objek orang telah dibuat\nBernama "+this.nama);
    }

}
