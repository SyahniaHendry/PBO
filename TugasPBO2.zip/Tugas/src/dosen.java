public class dosen extends elemen {
    private int JumlahHariKerja;
    private int jamsibuk;

    public dosen(String nama, int JumlahHariKerja) {
        super(nama);
        jamsibuk = JumlahHariKerja * 8;

    }

    public void kirim() {
        System.out.println(getnama() + " adalah seorang dosen dengan jam sibuk " + getJamSibuk());
    }

    public int getJamSibuk() {
        return jamsibuk;
    }

}