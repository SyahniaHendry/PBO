
public class app {
    public static void main(String[] args) {
        int kesibukanjam;
        // Polymorphism
        asdos a = new asdos("Fairuzikun", 24, 1);
        asdos b = new asdos("Angel-chan", 21, 1);
        elemen c = new dosen("Raja OP Damanik", 5); // upcasting
        dosen d = new dosen("Nivotko", 3);
        mahasiswa e = new mahasiswa("Firman", 20);
        mahasiswa f = new mahasiswa("Nid to pass this sem", 23);

        dosen dosendown = (dosen) d; // downcasting

        a.kirim();
        b.kirim();
        c.kirim();
        dosendown.kirim();
        e.kirim();
        f.kirim();
        d.kirim();

        kesibukanjam = a.jamsibuk + c.getJamSibuk() + b.jamsibuk + e.jamsibuk
                + f.jamsibuk + d.getJamSibuk();

        System.out.println("Total jam sibuk elemen Fasilkom adalah " + kesibukanjam);

    }

}