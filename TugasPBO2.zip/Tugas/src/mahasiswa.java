public class mahasiswa extends elemen {

    private int sks;
    public int jamsibuk;

    public mahasiswa(String nama, int sks) {
        super(nama);
        jamsibuk = sks * 3;

    }

    public void kirim() {
        System.out.println(getnama() + " adalah seorang mahasiswa dengan jam sibuk " + getJamSibuk());
    }

    public int getJamSibuk() {
        return jamsibuk;
    }

}