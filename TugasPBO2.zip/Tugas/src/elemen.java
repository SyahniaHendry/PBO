public class elemen {
    private String nama;
    public int total;
    public String type;
    public int JamSibuk;

    public elemen(String nama) {
        this.nama = nama;
    }

    public String getnama() {
        return nama;
    }
    public int getJamSibuk(){
        return JamSibuk;
    }
    public void kirim() {
        
    }
}