public class asdos extends mahasiswa {
    private int JamNgasdos;

    public asdos(String nama, int sks, int JamNgasdos) {
        super(nama, sks);
        jamsibuk = jamsibuk + JamNgasdos;
    }

    public int getJamSibuk() {
        return jamsibuk;
    }

    public void kirim() {
        System.out.println(getnama() + " adalah seorang asdos dengan jam sibuk " + getJamSibuk());
    }

}
